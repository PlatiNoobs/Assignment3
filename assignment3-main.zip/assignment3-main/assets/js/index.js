function test(params){
    alert('test');
}